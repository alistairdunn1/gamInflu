library(testthat)
library(gamInflu)

test_check("gamInflu")
