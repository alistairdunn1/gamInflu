#' Test and Example Functions for Generalized Gamma Family
#'
#' This file contains test functions and examples for the generalized gamma
#' family implementation in the gamInflu package.

#' @title Example Usage of Generalized Gamma Family
#' @description Demonstrates how to use the gengamma() family with mgcv::gam()
#' @return A fitted gam object if successful, NULL if fitting fails
#' @examples
#' \dontrun{
#' # Run the example
#' fit <- example_gengamma()
#' if (!is.null(fit)) {
#'   plot(fit, pages = 1)
#'   gam.check(fit)
#' }
#' }
#' @export
example_gengamma <- function() {
  cat("Example usage of gengamma family:\n\n")

  # Simulate data
  set.seed(42)
  n <- 300
  x1 <- runif(n, 0, 1)
  x2 <- runif(n, 0, 1)

  # True smooth functions
  f1 <- 2 * sin(2 * pi * x1)
  f2 <- exp(2 * x2) - 3.5

  # True parameters
  mu_true <- exp(1 + 0.5 * f1 + 0.3 * f2)
  sigma_true <- 0.4
  Q_true <- 0.8

  # Generate response using approximate method
  y <- rlnorm(n, log(mu_true) + rnorm(n, 0, sigma_true), sigma_true * abs(Q_true))
  y <- pmax(y, 1e-6) # Ensure positive

  # Create data frame
  dat <- data.frame(y = y, x1 = x1, x2 = x2)

  # Fit GAM
  cat("Fitting GAM with generalized gamma family...\n")

  tryCatch(
    {
      fit <- mgcv::gam(y ~ s(x1, k = 10) + s(x2, k = 10),
        family = gengamma(),
        data = dat,
        method = "REML"
      )

      cat("Model fitted successfully!\n")
      print(summary(fit))

      return(fit)
    },
    error = function(e) {
      cat("Error in fitting:", e$message, "\n")
      cat("This may require fine-tuning of initial values or link functions.\n")
      return(NULL)
    }
  )
}

#' @title Test Basic Generalized Gamma Distribution Functions
#' @description Tests the basic distribution functions (dgg, pgg, qgg, rgg)
#' @return TRUE if all tests pass, FALSE otherwise
#' @export
test_gengamma_basic <- function() {
  cat("Testing basic generalized gamma distribution functions...\n")

  # Test parameters
  mu <- 0
  sigma <- 1
  Q <- 0.5

  # Test that density integrates to 1 (approximately)
  x_seq <- seq(0.01, 10, length.out = 1000)
  dx <- diff(x_seq)[1]
  integral <- sum(dgg(x_seq, mu, sigma, Q) * dx)

  cat("Density integration test:", round(integral, 4), "≈ 1\n")

  # Test quantile-probability consistency
  p_test <- c(0.1, 0.25, 0.5, 0.75, 0.9)
  q_test <- qgg(p_test, mu, sigma, Q)
  p_back <- pgg(q_test, mu, sigma, Q)

  cat("Quantile-probability consistency:\n")
  for (i in seq_along(p_test)) {
    cat(sprintf(
      "  P = %.2f -> Q = %.3f -> P = %.3f\n",
      p_test[i], q_test[i], p_back[i]
    ))
  }

  # Test random generation
  set.seed(123)
  r_sample <- rgg(1000, mu, sigma, Q)

  cat("Random generation test:\n")
  cat("  Sample size:", length(r_sample), "\n")
  cat("  All positive:", all(r_sample > 0), "\n")
  cat("  Sample mean:", round(mean(r_sample), 3), "\n")
  cat("  Sample median:", round(median(r_sample), 3), "\n")

  # Check special case: Q near 0 (log-normal)
  Q_small <- 1e-8
  x_test <- 2
  dens_gg <- dgg(x_test, mu, sigma, Q_small, log = TRUE)
  dens_ln <- dlnorm(x_test, mu, sigma, log = TRUE)

  cat("Log-normal limit test (Q → 0):\n")
  cat("  GenGamma density:", round(dens_gg, 6), "\n")
  cat("  Log-normal density:", round(dens_ln, 6), "\n")
  cat("  Difference:", round(abs(dens_gg - dens_ln), 8), "\n")

  return(TRUE)
}

#' @title Test Generalized Gamma Family with Simple GAM
#' @description Tests the gengamma family with a simple GAM fit
#' @return TRUE if test passes, FALSE otherwise
#' @export
test_gengamma_gam <- function() {
  cat("Testing gengamma family with simple GAM...\n")

  # Simple test data
  set.seed(456)
  n <- 100
  x <- runif(n, 0, 1)

  # Simple relationship
  mu_true <- exp(1 + 2 * x)
  y <- rgg(n, log(mu_true), 0.3, 0.5)

  dat <- data.frame(y = y, x = x)

  tryCatch(
    {
      # Fit simple GAM
      fit <- mgcv::gam(y ~ s(x, k = 5),
        family = gengamma(),
        data = dat
      )

      cat("Simple GAM fitted successfully!\n")
      cat("Deviance explained:", round(summary(fit)$dev.expl * 100, 1), "%\n")
      cat("Number of theta parameters:", fit$family$n.theta, "\n")

      # Check family object properties
      cat("Family name:", fit$family$family, "\n")
      cat("Link functions:", paste(fit$family$link, collapse = ", "), "\n")

      return(TRUE)
    },
    error = function(e) {
      cat("Error in simple GAM test:", e$message, "\n")
      return(FALSE)
    }
  )
}

# Run tests if script is executed directly
if (interactive() || identical(commandArgs(trailingOnly = TRUE), "test")) {
  cat("Running generalized gamma family tests...\n\n")

  test_gengamma_basic()
  cat("\n", rep("=", 50), "\n\n")

  test_gengamma_gam()
  cat("\n", rep("=", 50), "\n\n")

  example_gengamma()
}
