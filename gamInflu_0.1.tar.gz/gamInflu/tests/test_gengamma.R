#' Test and Example Functions for Generalized Gamma Family
#'
#' This file contains test functions and examples for the generalized gamma
#' family implementation in the gamInflu package.

#' @title Example Usage of Generalized Gamma Family
#' @description Demonstrates how to use the gengamma() family with mgcv::gam()
#' @return A fitted gam object if successful, NULL if fitting fails
#' @examples
#' \dontrun{
#' # Run the example
#' fit <- example_gengamma()
#' if (!is.null(fit)) {
#'   plot(fit, pages = 1)
#'   gam.check(fit)
#' }
#' }
#' @export
example_gengamma <- function() {
  cat("Example usage of gengamma family:\n\n")

  # Simulate data
  set.seed(42)
  n <- 300
  x1 <- runif(n, 0, 1)
  x2 <- runif(n, 0, 1)

  # True smooth functions
  f1 <- 2 * sin(2 * pi * x1)
  f2 <- exp(2 * x2) - 3.5

  # True parameters
  mu_true <- exp(1 + 0.5 * f1 + 0.3 * f2)
  sigma_true <- 0.4
  Q_true <- 0.8

  # Generate response using approximate method
  y <- rlnorm(n, log(mu_true) + rnorm(n, 0, sigma_true), sigma_true * abs(Q_true))
  y <- pmax(y, 1e-6) # Ensure positive

  # Create data frame
  dat <- data.frame(y = y, x1 = x1, x2 = x2)

  # Fit GAM
  cat("Fitting GAM with generalized gamma family...\n")

  tryCatch(
    {
      fit <- mgcv::gam(y ~ s(x1, k = 10) + s(x2, k = 10),
        family = gengamma(),
        data = dat,
        method = "REML"
      )

      cat("Model fitted successfully!\n")
      print(summary(fit))

      return(fit)
    },
    error = function(e) {
      cat("Error in fitting:", e$message, "\n")
      cat("This may require fine-tuning of initial values or link functions.\n")
      return(NULL)
    }
  )
}

#' @title Test Basic Generalized Gamma Distribution Functions
#' @description Tests the basic distribution functions (dgg, pgg, qgg, rgg)
#' @return TRUE if all tests pass, FALSE otherwise
#' @export
test_gengamma_basic <- function() {
  cat("Testing basic generalized gamma distribution functions...\n")

  # Test parameters
  mu <- 0
  sigma <- 1
  Q <- 0.5

  # Test that density integrates to 1 (approximately)
  x_seq <- seq(0.01, 10, length.out = 1000)
  dx <- diff(x_seq)[1]
  integral <- sum(dgg(x_seq, mu, sigma, Q) * dx)

  cat("Density integration test:", round(integral, 4), "≈ 1\n")

  # Test quantile-probability consistency
  p_test <- c(0.1, 0.25, 0.5, 0.75, 0.9)
  q_test <- qgg(p_test, mu, sigma, Q)
  p_back <- pgg(q_test, mu, sigma, Q)

  cat("Quantile-probability consistency:\n")
  for (i in seq_along(p_test)) {
    cat(sprintf(
      "  P = %.2f -> Q = %.3f -> P = %.3f\n",
      p_test[i], q_test[i], p_back[i]
    ))
  }

  # Test random generation
  set.seed(123)
  r_sample <- rgg(1000, mu, sigma, Q)

  cat("Random generation test:\n")
  cat("  Sample size:", length(r_sample), "\n")
  cat("  All positive:", all(r_sample > 0), "\n")
  cat("  Sample mean:", round(mean(r_sample), 3), "\n")
  cat("  Sample median:", round(median(r_sample), 3), "\n")

  # Check special case: Q near 0 (log-normal)
  Q_small <- 1e-8
  x_test <- 2
  dens_gg <- dgg(x_test, mu, sigma, Q_small, log = TRUE)
  dens_ln <- dlnorm(x_test, mu, sigma, log = TRUE)

  cat("Log-normal limit test (Q → 0):\n")
  cat("  GenGamma density:", round(dens_gg, 6), "\n")
  cat("  Log-normal density:", round(dens_ln, 6), "\n")
  cat("  Difference:", round(abs(dens_gg - dens_ln), 8), "\n")

  return(TRUE)
}

#' @title Test Generalized Gamma Family with Simple GAM
#' @description Tests the gengamma family with a simple GAM fit
#' @return TRUE if test passes, FALSE otherwise
#' @export
test_gengamma_gam <- function() {
  cat("Testing gengamma family with simple GAM...\n")

  # Simple test data
  set.seed(456)
  n <- 100
  x <- runif(n, 0, 1)

  # Simple relationship
  mu_true <- exp(1 + 2 * x)
  y <- rgg(n, log(mu_true), 0.3, 0.5)

  dat <- data.frame(y = y, x = x)

  tryCatch(
    {
      # Fit simple GAM
      fit <- mgcv::gam(y ~ s(x, k = 5),
        family = gengamma(),
        data = dat
      )

      cat("Simple GAM fitted successfully!\n")
      cat("Deviance explained:", round(summary(fit)$dev.expl * 100, 1), "%\n")
      cat("Number of theta parameters:", fit$family$n.theta, "\n")

      # Check family object properties
      cat("Family name:", fit$family$family, "\n")
      cat("Link functions:", paste(fit$family$link, collapse = ", "), "\n")

      return(TRUE)
    },
    error = function(e) {
      cat("Error in simple GAM test:", e$message, "\n")
      return(FALSE)
    }
  )
}

#' @title Log-normal vs Generalised Gamma Simulation Comparison
#' @description Simulates data from a log-normal distribution and compares
#' fitting with both log-normal (Gaussian with log link) and generalised gamma families
#' @return A list containing comparison results
#' @export
simulate_lognormal_vs_gengamma <- function() {
  cat("=== Log-normal vs Generalised Gamma Simulation ===\n\n")

  # Set up simulation parameters
  set.seed(123)
  n <- 500
  x1 <- runif(n, 0, 1)
  x2 <- runif(n, 0, 1)

  # True smooth functions for simulation
  f1_true <- 2 * sin(2 * pi * x1)
  f2_true <- 1.5 * (x2 - 0.5)^2

  # True log-normal parameters
  mu_log_true <- 1 + 0.8 * f1_true + 0.6 * f2_true
  sigma_log_true <- 0.5

  # Generate log-normal data
  y_lognormal <- rlnorm(n, mu_log_true, sigma_log_true)

  # Create data frame
  dat <- data.frame(
    y = y_lognormal,
    x1 = x1,
    x2 = x2,
    mu_true = exp(mu_log_true) # Store true mean for comparison
  )

  cat("Generated", n, "observations from log-normal distribution\n")
  cat("True sigma =", sigma_log_true, "\n")
  cat("Response range: [", round(min(y_lognormal), 3), ",", round(max(y_lognormal), 3), "]\n\n")

  # Fit 1: Gaussian family with log link (traditional log-normal approach)
  cat("Fitting Model 1: Gaussian family with log link...\n")

  fit_gaussian <- tryCatch(
    {
      mgcv::gam(y ~ s(x1, k = 15) + s(x2, k = 15),
        family = gaussian(link = "log"),
        data = dat,
        method = "REML"
      )
    },
    error = function(e) {
      cat("Error in Gaussian fit:", e$message, "\n")
      return(NULL)
    }
  )

  # Fit 2: Generalised gamma family
  cat("Fitting Model 2: Generalised gamma family...\n")

  fit_gengamma <- tryCatch(
    {
      mgcv::gam(y ~ s(x1, k = 15) + s(x2, k = 15),
        family = gengamma(),
        data = dat,
        method = "REML"
      )
    },
    error = function(e) {
      cat("Error in generalised gamma fit:", e$message, "\n")
      return(NULL)
    }
  )

  # Compare results
  cat("\n=== Model Comparison Results ===\n")

  results <- list(
    gaussian_fit = fit_gaussian,
    gengamma_fit = fit_gengamma,
    true_data = dat
  )

  if (!is.null(fit_gaussian)) {
    cat("\nGaussian (log link) Model:\n")
    cat("  AIC:", round(AIC(fit_gaussian), 2), "\n")
    cat("  Deviance explained:", round(summary(fit_gaussian)$dev.expl * 100, 1), "%\n")
    cat("  GCV score:", round(fit_gaussian$gcv.ubre, 4), "\n")

    # Extract estimated parameters (approximation for log-normal)
    # In Gaussian with log link, the variance parameter relates to sigma
    cat("  Scale parameter:", round(sqrt(summary(fit_gaussian)$scale), 4), "\n")
  }

  if (!is.null(fit_gengamma)) {
    cat("\nGeneralised Gamma Model:\n")
    cat("  AIC:", round(AIC(fit_gengamma), 2), "\n")
    cat("  Deviance explained:", round(summary(fit_gengamma)$dev.expl * 100, 1), "%\n")
    cat("  GCV score:", round(fit_gengamma$gcv.ubre, 4), "\n")

    # Extract theta parameters
    if (!is.null(fit_gengamma$family$getTheta)) {
      theta <- fit_gengamma$family$getTheta(fit_gengamma)
      if (length(theta) >= 2) {
        sigma_est <- exp(theta[1])
        Q_est <- theta[2]
        cat("  Estimated sigma:", round(mean(sigma_est), 4), "\n")
        cat("  Estimated Q:", round(mean(Q_est), 4), "\n")
        cat("  Q close to 0 (log-normal limit)?", abs(mean(Q_est)) < 0.1, "\n")
      }
    }
  }

  # Prediction comparison on a grid
  if (!is.null(fit_gaussian) && !is.null(fit_gengamma)) {
    cat("\n=== Prediction Comparison ===\n")

    # Create prediction grid
    x1_grid <- seq(0, 1, length.out = 20)
    x2_grid <- seq(0, 1, length.out = 20)
    pred_grid <- expand.grid(x1 = x1_grid, x2 = x2_grid)

    # Get predictions
    pred_gaussian <- predict(fit_gaussian, newdata = pred_grid, type = "response")
    pred_gengamma <- predict(fit_gengamma, newdata = pred_grid, type = "response")

    # True predictions
    f1_grid <- 2 * sin(2 * pi * pred_grid$x1)
    f2_grid <- 1.5 * (pred_grid$x2 - 0.5)^2
    mu_true_grid <- 1 + 0.8 * f1_grid + 0.6 * f2_grid
    true_pred <- exp(mu_true_grid)

    # Calculate prediction errors
    rmse_gaussian <- sqrt(mean((pred_gaussian - true_pred)^2))
    rmse_gengamma <- sqrt(mean((pred_gengamma - true_pred)^2))

    cat("  RMSE Gaussian:", round(rmse_gaussian, 4), "\n")
    cat("  RMSE Generalised Gamma:", round(rmse_gengamma, 4), "\n")

    # Correlation with truth
    cor_gaussian <- cor(pred_gaussian, true_pred)
    cor_gengamma <- cor(pred_gengamma, true_pred)

    cat("  Correlation with truth (Gaussian):", round(cor_gaussian, 4), "\n")
    cat("  Correlation with truth (Gen. Gamma):", round(cor_gengamma, 4), "\n")

    results$predictions <- data.frame(
      x1 = pred_grid$x1,
      x2 = pred_grid$x2,
      true = true_pred,
      gaussian = pred_gaussian,
      gengamma = pred_gengamma
    )
  }

  # Model selection
  if (!is.null(fit_gaussian) && !is.null(fit_gengamma)) {
    cat("\n=== Model Selection ===\n")
    aic_diff <- AIC(fit_gengamma) - AIC(fit_gaussian)
    cat("  AIC difference (GenGamma - Gaussian):", round(aic_diff, 2), "\n")

    if (abs(aic_diff) < 2) {
      cat("  Interpretation: Models are equivalent (|ΔAIC| < 2)\n")
    } else if (aic_diff < -2) {
      cat("  Interpretation: Generalised gamma is preferred (ΔAIC < -2)\n")
    } else {
      cat("  Interpretation: Gaussian is preferred (ΔAIC > 2)\n")
    }
  }

  cat("\n=== Summary ===\n")
  cat("This simulation tests whether the generalised gamma family can\n")
  cat("appropriately recover log-normal data (Q → 0 limit case).\n")
  cat("Good performance indicates the family is working correctly.\n\n")

  return(invisible(results))
}

# Run tests if script is executed directly
if (interactive() || identical(commandArgs(trailingOnly = TRUE), "test")) {
  cat("Running generalized gamma family tests...\n\n")

  test_gengamma_basic()
  cat("\n", rep("=", 50), "\n\n")

  test_gengamma_gam()
  cat("\n", rep("=", 50), "\n\n")

  example_gengamma()
  cat("\n", rep("=", 50), "\n\n")

  # Run the simulation comparison
  simulate_lognormal_vs_gengamma()
}
