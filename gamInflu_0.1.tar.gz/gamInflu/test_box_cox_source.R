#!/usr/bin/env Rscript

cat("Loading source file...\n")
# Load the new functions
source("R/box_cox_transform.R")
cat("Source file loaded!\n\n")

# Test script for Box-Cox transformation functions
library(mgcv)

# Set seed for reproducibility
set.seed(123)

# Create sample data with skewed response
n <- 200
x1 <- runif(n, 0, 10)
x2 <- runif(n, -2, 2)
year <- factor(rep(2001:2010, each = 20))

# Create response with skewed distribution (needs transformation)
true_mean <- exp(1 + 0.2 * x1 - 0.5 * x2)
y_skewed <- rgamma(n, shape = 1, scale = true_mean / 2)

# Create data frame
data <- data.frame(
  response = y_skewed,
  x1 = x1,
  x2 = x2,
  year = year
)

cat("Testing Box-Cox transformation functions\n")
cat("======================================\n\n")

# Check if required packages are available
if (!requireNamespace("MASS", quietly = TRUE)) {
  cat("MASS package is required but not available.\n")
  cat("Please install it with: install.packages('MASS')\n")
  quit(status = 1)
}

# Test basic box_cox_transform function
cat("1. Testing basic box_cox_transform function\n")
cat("------------------------------------------\n")
tryCatch(
  {
    bc <- box_cox_transform(data$response)
    cat("Estimated optimal lambda:", bc$lambda, "\n\n")
  },
  error = function(e) {
    cat("Error in box_cox_transform:", conditionMessage(e), "\n\n")
  }
)

# Test with different lambda values
cat("2. Testing different lambda values\n")
cat("--------------------------------\n")
tryCatch(
  {
    bc_log <- box_cox_transform(data$response, lambda = 0)
    bc_sqrt <- box_cox_transform(data$response, lambda = 0.5)
    bc_identity <- box_cox_transform(data$response, lambda = 1)

    cat("Lambda 0 (log): Mean of transformed data =", mean(bc_log$transformed), "\n")
    cat("Lambda 0.5 (sqrt): Mean of transformed data =", mean(bc_sqrt$transformed), "\n")
    cat("Lambda 1 (identity): Mean of transformed data =", mean(bc_identity$transformed), "\n\n")
  },
  error = function(e) {
    cat("Error testing lambda values:", conditionMessage(e), "\n\n")
  }
)

# Test inverse transformation
cat("3. Testing inverse transformation\n")
cat("------------------------------\n")
tryCatch(
  {
    y_orig <- data$response[1:5]
    y_trans <- bc_log$transformed[1:5]
    y_back <- inverse_box_cox(y_trans, lambda = 0)

    cat("Original values:", y_orig, "\n")
    cat("Transformed values:", y_trans, "\n")
    cat("Back-transformed values:", y_back, "\n")
    cat("Difference (original - back):", y_orig - y_back, "\n\n")
  },
  error = function(e) {
    cat("Error testing inverse transformation:", conditionMessage(e), "\n\n")
  }
)

# Test box_cox_gam function
cat("4. Testing box_cox_gam function\n")
cat("----------------------------\n")
# Fit a regular GAM
cat("Fitting regular GAM...\n")
tryCatch(
  {
    gam_regular <- gam(response ~ year + s(x1) + s(x2), data = data, family = gaussian())

    # Fit a Box-Cox transformed GAM with log transformation
    cat("Fitting Box-Cox transformed GAM with log transformation (lambda = 0)...\n")
    bc_gam_log <- box_cox_gam(response ~ year + s(x1) + s(x2), data = data, lambda = 0)

    cat("Regular GAM AIC:", AIC(gam_regular), "\n")
  },
  error = function(e) {
    cat("Error testing box_cox_gam:", conditionMessage(e), "\n\n")
  }
)

cat("\nTest completed!\n")
