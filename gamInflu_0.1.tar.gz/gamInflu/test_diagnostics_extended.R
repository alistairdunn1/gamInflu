#!/usr/bin/env Rscript

# Comprehensive test for gamInflu with different model families and links
library(mgcv)
library(gamInflu)

# Set seed for reproducibility
set.seed(123)

# Create sample data
n <- 200
depth <- runif(n, 10, 100)
year <- factor(rep(2010:2019, each = 20))

# Generate response variables for different model types
# Gamma with inverse link
true_mu_inverse <- 1 / (0.01 + 0.005 * depth)
y_gamma_inverse <- rgamma(n, shape = 2, scale = true_mu_inverse / 2)
y_gamma_inverse <- pmax(y_gamma_inverse, 1e-6)

# Gamma with log link
true_mu_log <- exp(1 + 0.01 * depth)
y_gamma_log <- rgamma(n, shape = 2, scale = true_mu_log / 2)

# Gaussian
y_gaussian <- 100 + 2 * depth + rnorm(n, 0, 20)

  # Create data frames with year as factor
data_gamma_inverse <- data.frame(cpue = y_gamma_inverse, depth = depth, year = year)
data_gamma_log <- data.frame(cpue = y_gamma_log, depth = depth, year = year)
data_gaussian <- data.frame(cpue = y_gaussian, depth = depth, year = year)

# Ensure year is a factor in all datasets
data_gamma_inverse$year <- as.factor(data_gamma_inverse$year)
data_gamma_log$year <- as.factor(data_gamma_log$year)
data_gaussian$year <- as.factor(data_gaussian$year)

run_test <- function(data, family_spec, name) {
  cat("\n=================================================\n")
  cat("Testing:", name, "\n")
  cat("=================================================\n")
  
  tryCatch({
    # Fit model
    cat("Fitting model...\n")
    mod <- gam(cpue ~ year + s(depth), data = data, family = family_spec)
    cat("Model fitted successfully!\n")
    
    # Create gam_influence object
    cat("Creating gam_influence object...\n")
    gi <- gam_influence(mod, focus = "year")
    cat("gam_influence created successfully!\n")
    
    # Test coefficient method
    cat("\nTesting coefficient method:\n")
    tryCatch({
      gi_coef <- calculate_influence(gi, use_coeff_method = TRUE)
      cat("✓ Coefficient method succeeded\n")
      
      # Basic validation
      if (!is.null(gi_coef$calculated$indices)) {
        cat("  Number of indices:", nrow(gi_coef$calculated$indices), "\n")
        range_txt <- paste(range(gi_coef$calculated$indices$standardised_index, na.rm = TRUE), collapse = " - ")
        cat("  Standardised index range:", range_txt, "\n")
      }
    }, error = function(e) {
      cat("✗ Coefficient method failed:", conditionMessage(e), "\n")
    }, warning = function(w) {
      cat("⚠ Coefficient method warning:", conditionMessage(w), "\n")
    })
    
    # Test prediction method
    cat("\nTesting prediction method:\n")
    tryCatch({
      gi_pred <- calculate_influence(gi, use_coeff_method = FALSE)
      cat("✓ Prediction method succeeded\n")
      
      # Basic validation
      if (!is.null(gi_pred$calculated$indices)) {
        cat("  Number of indices:", nrow(gi_pred$calculated$indices), "\n")
        range_txt <- paste(range(gi_pred$calculated$indices$standardised_index, na.rm = TRUE), collapse = " - ")
        cat("  Standardised index range:", range_txt, "\n")
      }
    }, error = function(e) {
      cat("✗ Prediction method failed:", conditionMessage(e), "\n")
    }, warning = function(w) {
      cat("⚠ Prediction method warning:", conditionMessage(w), "\n")
    })
    
    # Test diagnostics
    cat("\nTesting diagnostics:\n")
    tryCatch({
      gi_diagnostics <- diagnose_model_influence(gi_pred)
      cat("✓ Diagnostics succeeded\n")
      
      # Print diagnostics summary
      print(summary(gi_diagnostics))
    }, error = function(e) {
      cat("✗ Diagnostics failed:", conditionMessage(e), "\n")
    }, warning = function(w) {
      cat("⚠ Diagnostics warning:", conditionMessage(w), "\n")
    })
    
  }, error = function(e) {
    cat("✗ Test failed:", conditionMessage(e), "\n")
  })
  
  cat("\nTest completed!\n")
}

# Run tests for different model families
run_test(data_gamma_inverse, Gamma(link = "inverse"), "Gamma with inverse link")
run_test(data_gamma_log, Gamma(link = "log"), "Gamma with log link") 
run_test(data_gaussian, gaussian(), "Gaussian with identity link")

cat("\nAll tests completed!\n")
