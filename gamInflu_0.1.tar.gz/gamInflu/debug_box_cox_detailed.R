#!/usr/bin/env Rscript

# Load the functions but with additional debug
cat("Loading functions with debug...\n")
box_cox_transform <- function(y, lambda = NULL, lower = -2, upper = 2, eps = 0) {
  # Input validation
  if (!is.numeric(y)) {
    stop("Response variable 'y' must be numeric", call. = FALSE)
  }

  cat("Input validation passed\n")

  # Add epsilon if specified to handle zeros or negative values
  if (eps > 0) {
    y_adj <- y + eps
    cat("Added epsilon to data\n")
  } else {
    y_adj <- y
    cat("No epsilon added\n")
  }

  cat("y_adj created with length", length(y_adj), "\n")

  # Check for non-positive values
  if (any(y_adj <= 0)) {
    stop("Box-Cox transformation requires strictly positive values. ",
      "Use 'eps' parameter to add a constant to your data.",
      call. = FALSE
    )
  }

  cat("All values positive\n")

  # If lambda not provided, estimate optimal lambda
  if (is.null(lambda)) {
    cat("Lambda is NULL, will estimate\n")
    # Only estimate if MASS package is available
    if (!requireNamespace("MASS", quietly = TRUE)) {
      warning("MASS package not available. Using lambda = 0 (log transformation) as default.")
      lambda <- 0
    } else {
      cat("Using MASS to estimate lambda\n")
      # Use MASS::boxcox to find optimal lambda
      # First create a simple linear model to use with boxcox
      dummy_x <- seq_along(y_adj)
      cat("Created dummy_x with length", length(dummy_x), "\n")

      dummy_model <- stats::lm(y_adj ~ dummy_x)
      cat("Created dummy model\n")

      # Find optimal lambda
      bc <- MASS::boxcox(dummy_model,
        lambda = seq(lower, upper, by = 0.1),
        plotit = FALSE
      )
      cat("MASS::boxcox completed\n")

      lambda <- bc$x[which.max(bc$y)]
      cat("Estimated lambda =", lambda, "\n")

      # Round lambda to common values if it's close
      common_lambdas <- c(-1, -0.5, 0, 0.5, 1, 2)
      for (cl in common_lambdas) {
        if (abs(lambda - cl) < 0.05) {
          lambda <- cl
          cat("Rounded lambda to", lambda, "\n")
          break
        }
      }
    }
  } else {
    cat("Using provided lambda =", lambda, "\n")
  }

  # Apply Box-Cox transformation
  if (abs(lambda) < 1e-10) {
    # Lambda is very close to 0, use log transformation
    transformed <- log(y_adj)
    lambda <- 0 # Set exactly to 0 for clarity
    cat("Applied log transformation\n")
  } else {
    # Use standard Box-Cox formula
    transformed <- (y_adj^lambda - 1) / lambda
    cat("Applied Box-Cox with lambda =", lambda, "\n")
  }

  # Return transformation results
  result <- list(
    transformed = transformed,
    lambda = lambda,
    original = y,
    eps = eps
  )

  class(result) <- c("box_cox_transform", "list")
  cat("Returning result\n")

  return(result)
}

inverse_box_cox <- function(x, lambda, eps = 0) {
  # Input validation
  if (!is.numeric(x)) {
    stop("Input 'x' must be numeric", call. = FALSE)
  }
  if (!is.numeric(lambda) || length(lambda) != 1) {
    stop("Lambda must be a single numeric value", call. = FALSE)
  }

  # Apply inverse Box-Cox transformation
  if (abs(lambda) < 1e-10) {
    # Lambda is very close to 0, use exp
    y <- exp(x)
  } else {
    # Use standard inverse Box-Cox formula
    y <- (lambda * x + 1)^(1 / lambda)
  }

  # Subtract epsilon if it was added
  if (eps > 0) {
    y <- y - eps
  }

  return(y)
}

# Set seed for reproducibility
set.seed(123)

# Create sample data with skewed response
n <- 100
y_skewed <- rgamma(n, shape = 2, scale = 3)

cat("\nTesting box_cox_transform function...\n")
cat("===================================\n")

# Test automatic lambda estimation
tryCatch(
  {
    bc <- box_cox_transform(y_skewed)
    cat("\nAutomatic lambda estimation succeeded!\n")
    cat("Estimated lambda =", bc$lambda, "\n")
  },
  error = function(e) {
    cat("\nError in automatic lambda estimation:", conditionMessage(e), "\n")
  }
)

# Test with fixed lambda
tryCatch(
  {
    bc_log <- box_cox_transform(y_skewed, lambda = 0)
    cat("\nFixed lambda (log) transformation succeeded!\n")
  },
  error = function(e) {
    cat("\nError in fixed lambda transformation:", conditionMessage(e), "\n")
  }
)

# Test inverse transformation
tryCatch(
  {
    y_trans <- bc_log$transformed[1:5]
    y_back <- inverse_box_cox(y_trans, lambda = 0)

    cat("\nInverse transformation succeeded!\n")
    cat("Original:", y_skewed[1:5], "\n")
    cat("Transformed:", y_trans, "\n")
    cat("Back-transformed:", y_back, "\n")
  },
  error = function(e) {
    cat("\nError in inverse transformation:", conditionMessage(e), "\n")
  }
)

cat("\nTest completed!\n")
