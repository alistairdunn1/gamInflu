# Simple test script for the Box-Cox transformation function
# This script only tests the basic transformation functionality

# Source the necessary file
source("c:/Users/alist/OneDrive/Projects/Software/gamInflu/gamInflu/R/box_cox_transform.R")

# Test with some basic data
set.seed(123)
y <- exp(rnorm(100)) # Generate some positive right-skewed data

# Test 1: Simple transformation with auto lambda
cat("Test 1: Box-Cox transformation with automatic lambda\n")
result <- box_cox_transform(y)
cat("Estimated lambda:", result$lambda, "\n")

# Test 2: Specific lambda values
cat("\nTest 2: Specific lambda values\n")
lambdas <- c(0, 0.5, 1, 2)
for (lambda in lambdas) {
  cat("Using lambda =", lambda, "\n")
  result <- box_cox_transform(y, lambda = lambda)
  cat("  - Mean of transformed data:", mean(result$transformed), "\n")
  cat("  - SD of transformed data:", sd(result$transformed), "\n")
}

# Test 3: Inverse transformation
cat("\nTest 3: Inverse transformation\n")
y_transform <- box_cox_transform(y, lambda = 0.5)$transformed
y_inverse <- inverse_box_cox(y_transform, lambda = 0.5)
cat("Original mean:", mean(y), "\n")
cat("Inverse transform mean:", mean(y_inverse), "\n")
cat("Mean absolute difference:", mean(abs(y - y_inverse)), "\n")

cat("\nTest completed successfully\n")
