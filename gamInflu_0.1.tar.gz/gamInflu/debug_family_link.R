#!/usr/bin/env Rscript

# Debug script for family/link detection in calculate_influence
library(mgcv)
library(gamInflu)

# Set seed for reproducibility
set.seed(123)

# Create sample data for testing Gamma with inverse link
n <- 200
depth <- runif(n, 10, 100)
year <- factor(rep(2010:2019, each = 20))

# Generate response variable appropriate for Gamma(inverse)
true_mu <- 1 / (0.01 + 0.005 * depth + rnorm(n, 0, 0.1))
y <- rgamma(n, shape = 2, scale = true_mu / 2)
y <- pmax(y, 1e-6)
y <- ifelse(is.finite(y), y, 1.0)

# Create data frame
test_data <- data.frame(
  cpue = y,
  depth = depth,
  year = year
)

# Test different family/link combinations
test_models <- list(
  gamma_inverse = gam(cpue ~ year + s(depth), data = test_data, family = Gamma(link = "inverse")),
  gamma_log = gam(cpue ~ year + s(depth), data = test_data, family = Gamma(link = "log")),
  gaussian_identity = gam(cpue ~ year + s(depth), data = test_data, family = gaussian())
)

debug_family_link <- function(model) {
  cat("\n==== Model Information ====\n")
  cat("Family:", model$family$family, "\n")
  cat("Link function:", model$family$link, "\n")
  
  # Check model family attributes
  cat("\nFamily object details:\n")
  str(model$family)
  
  # Get the inverse function
  cat("\nInverse link function test:\n")
  if (!is.null(model$family$linkinv)) {
    cat("linkinv exists:", head(model$family$linkinv(c(-1, 0, 1)), 3), "\n")
  } else {
    cat("linkinv does not exist\n")
  }
  
  # Test influence calculation with different methods
  gi <- gam_influence(model, focus = "year")
  
  cat("\nTesting coefficient method:\n")
  tryCatch({
    gi_coef <- calculate_influence(gi, use_coeff_method = TRUE)
    cat("✓ Coefficient method succeeded\n")
  }, error = function(e) {
    cat("✗ Coefficient method failed:", conditionMessage(e), "\n")
  }, warning = function(w) {
    cat("⚠ Coefficient method warning:", conditionMessage(w), "\n")
  })
  
  cat("\nTesting prediction method:\n")
  tryCatch({
    gi_pred <- calculate_influence(gi, use_coeff_method = FALSE)
    cat("✓ Prediction method succeeded\n")
  }, error = function(e) {
    cat("✗ Prediction method failed:", conditionMessage(e), "\n")
  }, warning = function(w) {
    cat("⚠ Prediction method warning:", conditionMessage(w), "\n")
  })
  
  cat("\n")
}

# Test each model
for (model_name in names(test_models)) {
  cat("\n\n=============================\n")
  cat("Testing model:", model_name, "\n")
  cat("=============================\n")
  debug_family_link(test_models[[model_name]])
}

cat("\nDebug complete!\n")
