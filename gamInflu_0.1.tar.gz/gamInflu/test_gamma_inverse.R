#!/usr/bin/env Rscript

# Simple test for gamInflu with Gamma(inverse) models
library(mgcv)
library(gamInflu)

# Set seed for reproducibility
set.seed(123)

# Create sample data
n <- 200
x <- runif(n, 0, 10)
year <- factor(rep(2001:2010, each = 20))

# Generate response for Gamma with inverse link
# For inverse link, mu = 1/eta, so larger eta means smaller mu
linear_predictor <- 1 + 0.1 * as.numeric(year) + 0.2 * x
mu <- 1 / linear_predictor
shape <- 2  # shape parameter for Gamma
scale <- mu / shape  # scale parameter to achieve target mean
y <- rgamma(n, shape = shape, scale = scale)

# Create data frame
data <- data.frame(
  response = y,
  year = year,
  x = x
)

cat("Testing gamInflu with Gamma(inverse)\n")
cat("====================================\n\n")

# Fit the model
cat("Fitting model...\n")
mod <- gam(response ~ year + s(x), data = data, family = Gamma(link = "inverse"))
cat("Model fitted!\n")
print(summary(mod))

# Create gam_influence object
cat("\nCreating gam_influence object...\n")
gi <- gam_influence(mod, focus = "year")
cat("gam_influence object created!\n")

# Run calculate_influence with coefficient method (should auto-switch to prediction)
cat("\nRunning calculate_influence...\n")
gi_calc <- calculate_influence(gi, use_coeff_method = TRUE)

cat("\nChecking results...\n")
if (!is.null(gi_calc$calculated$indices)) {
  cat("✓ Indices calculated successfully\n")
  cat("  Number of indices:", nrow(gi_calc$calculated$indices), "\n")
  cat("  Index range:", range(gi_calc$calculated$indices$standardised_index, na.rm = TRUE), "\n")
} else {
  cat("✗ Indices calculation failed\n")
}

if (!is.null(gi_calc$calculated$influences)) {
  cat("✓ Influences calculated successfully\n")
  cat("  Number of influences:", nrow(gi_calc$calculated$influences), "\n")
  cat("  Influence range:", range(gi_calc$calculated$influences$influence, na.rm = TRUE), "\n")
} else {
  cat("✗ Influence calculation failed\n")
}

# Try the diagnostics
cat("\nRunning diagnostics...\n")
di <- diagnose_model_influence(gi_calc)

cat("\nPrinting diagnostics summary:\n")
print(summary(di))

cat("\nTest completed successfully! ✓\n")
