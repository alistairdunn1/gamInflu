# Test script for Box-Cox transformation with GAM
# This script tests the Box-Cox transformation with GAM models

# Source the necessary files
source("c:/Users/alist/OneDrive/Projects/Software/gamInflu/gamInflu/R/box_cox_transform.R")

# Load required packages
if (!require("mgcv")) {
  install.packages("mgcv")
  library(mgcv)
}

# Set seed for reproducibility
set.seed(123)

# Generate sample data with heteroskedasticity (increasing variance)
n <- 200
x <- seq(0, 1, length.out = n)
# Generate right-skewed data with increasing variance
mu <- exp(2 * x)
sigma <- 0.2 + 2 * x # Variance increases with x
y <- mu + rnorm(n, 0, sigma)
# Ensure all values are positive (for Box-Cox)
y <- y - min(y) + 0.1

# Create data frame
test_data <- data.frame(
  y = y,
  x = x
)

# Test 1: Fit regular GAM model
cat("Test 1: Regular GAM model\n")
regular_gam <- gam(y ~ s(x), data = test_data, family = gaussian())
summary(regular_gam)

# Plot residuals for regular GAM
pdf("regular_gam_diagnostics.pdf")
par(mfrow = c(2, 2))
plot(regular_gam)
dev.off()

# Test 2: Box-Cox transformed GAM model
cat("\nTest 2: Box-Cox transformed GAM\n")

# Box-Cox transform the response directly
bc_transform <- box_cox_transform(test_data$y)
cat("Estimated lambda:", bc_transform$lambda, "\n")

# Create transformed data
test_data_transformed <- test_data
test_data_transformed$y_transformed <- bc_transform$transformed

# Fit GAM on transformed data
bc_manual_gam <- gam(y_transformed ~ s(x), data = test_data_transformed)
summary(bc_manual_gam)

# Plot residuals for transformed GAM
pdf("bc_manual_gam_diagnostics.pdf")
par(mfrow = c(2, 2))
plot(bc_manual_gam)
dev.off()

# Test 3: Using the box_cox_gam function
cat("\nTest 3: Using box_cox_gam function\n")
bc_auto_gam <- NULL
tryCatch(
  {
    bc_auto_gam <- box_cox_gam(y ~ s(x), data = test_data)
    cat("Box-Cox GAM fit successfully\n")
    summary(bc_auto_gam)
  },
  error = function(e) {
    cat("Error fitting box_cox_gam:", e$message, "\n")
  }
)

# Test 4: Predictions with the box_cox_gam model
cat("\nTest 4: Predictions from box_cox_gam\n")
if (!is.null(bc_auto_gam)) {
  # Create prediction data
  new_data <- data.frame(x = seq(0, 1, by = 0.1))

  # Make predictions with automatic back-transformation
  preds <- predict(bc_auto_gam, newdata = new_data)

  # Print predictions
  cat("Predictions (back-transformed):\n")
  print(data.frame(x = new_data$x, prediction = preds))

  # Compare with manual back-transformation
  preds_transformed <- predict(bc_auto_gam, newdata = new_data, back_transform = FALSE)
  preds_manual_bt <- inverse_box_cox(preds_transformed, lambda = bc_auto_gam$box_cox$lambda)

  # Check if they match
  cat(
    "Max difference between auto and manual back-transformation:",
    max(abs(preds - preds_manual_bt)), "\n"
  )
}

cat("\nTest completed\n")
