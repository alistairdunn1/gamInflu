#!/usr/bin/env Rscript

# Simplified debugging test
cat("Loading source file...\n")
source("R/box_cox_transform.R")
cat("Source file loaded!\n")

# Set seed for reproducibility
set.seed(123)

# Create simple data
y <- rgamma(100, shape = 2, scale = 3)
cat("Sample data created.\n")

# Define a simpler box_cox_transform function for debugging
simple_box_cox <- function(y, lambda = 0) {
  # Add small epsilon to ensure strictly positive values
  y_adj <- y + 1e-10

  if (lambda == 0) {
    # Log transformation
    return(log(y_adj))
  } else {
    # Box-Cox formula
    return((y_adj^lambda - 1) / lambda)
  }
}

# Test simple function
cat("\nTesting simple box_cox function...\n")
result_simple <- simple_box_cox(y)
cat("Simple function worked.\n")

# Now test our main function
cat("\nTesting main box_cox_transform function...\n")
tryCatch(
  {
    result <- box_cox_transform(y, lambda = 0)
    cat("Main function worked!\n")
  },
  error = function(e) {
    cat("ERROR:", conditionMessage(e), "\n")

    # Check existence of y_adj in function environment
    env_vars <- ls(envir = parent.frame())
    cat("Variables in environment:", paste(env_vars, collapse = ", "), "\n")
  }
)

cat("\nTest complete.\n")
