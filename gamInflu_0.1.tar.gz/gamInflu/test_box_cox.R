#!/usr/bin/env Rscript

# Test script for Box-Cox transformation functions
library(mgcv)
library(gamInflu)

# Set seed for reproducibility
set.seed(123)

# Create sample data with skewed response
n <- 200
x1 <- runif(n, 0, 10)
x2 <- runif(n, -2, 2)
year <- factor(rep(2001:2010, each = 20))

# Create response with skewed distribution (needs transformation)
true_mean <- exp(1 + 0.2 * x1 - 0.5 * x2)
y_skewed <- rgamma(n, shape = 1, scale = true_mean / 2)

# Create data frame
data <- data.frame(
  response = y_skewed,
  x1 = x1,
  x2 = x2,
  year = year
)

cat("Testing Box-Cox transformation functions\n")
cat("======================================\n\n")

# Test basic box_cox_transform function
cat("1. Testing basic box_cox_transform function\n")
cat("------------------------------------------\n")
bc <- box_cox_transform(data$response)
cat("Estimated optimal lambda:", bc$lambda, "\n\n")

# Test with different lambda values
cat("2. Testing different lambda values\n")
cat("--------------------------------\n")
bc_log <- box_cox_transform(data$response, lambda = 0)
bc_sqrt <- box_cox_transform(data$response, lambda = 0.5)
bc_identity <- box_cox_transform(data$response, lambda = 1)

cat("Lambda 0 (log): Mean of transformed data =", mean(bc_log$transformed), "\n")
cat("Lambda 0.5 (sqrt): Mean of transformed data =", mean(bc_sqrt$transformed), "\n")
cat("Lambda 1 (identity): Mean of transformed data =", mean(bc_identity$transformed), "\n\n")

# Test inverse transformation
cat("3. Testing inverse transformation\n")
cat("------------------------------\n")
y_orig <- data$response[1:5]
y_trans <- bc$transformed[1:5]
y_back <- inverse_box_cox(y_trans, lambda = bc$lambda)

cat("Original values:", y_orig, "\n")
cat("Transformed values:", y_trans, "\n")
cat("Back-transformed values:", y_back, "\n")
cat("Difference (original - back):", y_orig - y_back, "\n\n")

# Test box_cox_gam function
cat("4. Testing box_cox_gam function\n")
cat("----------------------------\n")
# Fit a regular GAM
cat("Fitting regular GAM...\n")
gam_regular <- gam(response ~ year + s(x1) + s(x2), data = data, family = gaussian())

# Fit a Box-Cox transformed GAM with automatic lambda
cat("Fitting Box-Cox transformed GAM with automatic lambda...\n")
bc_gam_auto <- box_cox_gam(response ~ year + s(x1) + s(x2), data = data)

# Fit a Box-Cox transformed GAM with log transformation
cat("Fitting Box-Cox transformed GAM with log transformation (lambda = 0)...\n")
bc_gam_log <- box_cox_gam(response ~ year + s(x1) + s(x2), data = data, lambda = 0)

cat("Regular GAM AIC:", AIC(gam_regular), "\n")
cat("Box-Cox GAM (auto) estimated lambda:", bc_gam_auto$box_cox$lambda, "\n")

# Test predictions
cat("\n5. Testing predictions\n")
cat("-------------------\n")
# Create new data for prediction
new_data <- data.frame(
  x1 = c(2, 5, 8),
  x2 = c(0, 1, -1),
  year = factor(c("2005", "2008", "2010"))
)

# Make predictions with both models
pred_regular <- predict(gam_regular, newdata = new_data)
pred_bc_auto <- predict(bc_gam_auto, newdata = new_data)
pred_bc_auto_transform <- predict(bc_gam_auto, newdata = new_data, back_transform = FALSE)
pred_bc_log <- predict(bc_gam_log, newdata = new_data)

cat("Regular GAM predictions:", pred_regular, "\n")
cat("Box-Cox GAM (auto) predictions:", pred_bc_auto, "\n")
cat("Box-Cox GAM (auto) predictions (transformed scale):", pred_bc_auto_transform, "\n")
cat("Box-Cox GAM (log) predictions:", pred_bc_log, "\n\n")

# Test compatibility with gam_influence
cat("6. Testing compatibility with gam_influence\n")
cat("---------------------------------------\n")
cat("Creating gam_influence objects...\n")

# Create gam_influence objects
gi_regular <- gam_influence(gam_regular, focus = "year")
gi_bc <- gam_influence_from_box_cox(bc_gam_auto, focus = "year")

# Calculate influence
cat("Calculating influence...\n")
gi_regular_calc <- calculate_influence(gi_regular)
gi_bc_calc <- calculate_influence(gi_bc)

# Check influence results
cat("Regular GAM influence completed:", !is.null(gi_regular_calc$calculated), "\n")
cat("Box-Cox GAM influence completed:", !is.null(gi_bc_calc$calculated), "\n\n")

# Print summary of results
cat("7. Summary and model comparison\n")
cat("---------------------------\n")
cat("Original data summary:\n")
print(summary(data$response))

cat("\nTransformed data summary (lambda =", bc$lambda, "):\n")
print(summary(bc$transformed))

cat("\nRegular GAM summary:\n")
print(summary(gam_regular))

cat("\nBox-Cox GAM summary:\n")
print(summary(bc_gam_auto))

cat("\nTest completed successfully!\n")
